package com.semmp.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemmpApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SemmpApiApplication.class, args);
	}

}
